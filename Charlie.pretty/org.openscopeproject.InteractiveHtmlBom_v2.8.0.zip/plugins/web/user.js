// EventHandler.registerCallback(IBOM_EVENT_TYPES.BOM_BODY_CHANGE_EVENT, () => {
//     for(var tr of bom.childNodes) {
//         tr.onclick = tr.onmousemove;
//         tr.onmousemove = null;
//     };
// });
